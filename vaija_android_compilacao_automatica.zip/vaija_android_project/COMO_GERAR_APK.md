# VaiJá — gerar APK automaticamente

Este projeto já está preparado para ser compilado como aplicativo Android.

## Método simples: GitHub Actions

1. Crie um repositório novo no GitHub.
2. Envie **todo o conteúdo desta pasta** para o repositório (não envie somente o ZIP).
3. Aguarde a ação **Gerar APK VaiJa** terminar.
4. Abra a execução concluída em **Actions**.
5. Na seção **Artifacts**, baixe **VaiJa-APK**.
6. Dentro do ZIP baixado estará `VaiJa.apk`.
7. Transfira `VaiJa.apk` para o celular e instale.

O workflow usa Java 17, Gradle 8.9 e Android Gradle Plugin 8.7.3.

## Observação

O APK produzido por este workflow é uma versão **debug**, adequada para teste e instalação direta. Para publicar na Google Play, será necessário gerar uma versão assinada/release com uma chave de assinatura.
