# VaiJá Android

Projeto Android do VaiJá, com interface responsiva para celular baseada na versão enviada.

- Package: `com.vaija.app`
- Min SDK: 23
- Target SDK: 35
- Versão: 1.0.0
- Entrada: `MainActivity` + WebView local
- Build automático: `.github/workflows/build-apk.yml`

Consulte `COMO_GERAR_APK.md` para gerar o APK automaticamente.
